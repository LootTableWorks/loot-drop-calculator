export async function loadItems(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Could not load item database: " + response.status);
  }

  const items = await response.json();
  if (!Array.isArray(items)) {
    throw new Error("Expected a top-level JSON array.");
  }
  return items;
}

export function indexById(items) {
  return new Map(items.map((item) => [item.id, item]));
}

export function filterItems(items, filters = {}) {
  return items.filter((item) =>
    Object.entries(filters).every(([key, value]) => !value || String(item[key]) === String(value))
  );
}

export function randomItem(items) {
  return items.length ? items[Math.floor(Math.random() * items.length)] : null;
}

// Node.js example:
// const fs = require("fs");
// const items = JSON.parse(fs.readFileSync("./items-premium.json", "utf8"));
