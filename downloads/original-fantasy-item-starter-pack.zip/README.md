# Original Fantasy Item Starter Pack

Open item-explorer.html first. It is a standalone offline browser for all 100 demo items and does not require installation or an internet connection.

## What You Receive

- item-explorer.html: search, filter, randomize, inspect, copy, and export items
- items.json: canonical structured data
- items.csv: spreadsheet-friendly data
- schema.json: validation schema
- examples.md: loot, shop, and crafting examples
- INTEGRATION-GUIDE.md: Unity, Godot, browser, and Node.js quickstart
- integrations/: working starter loaders for Unity, Godot 4, and JavaScript
- USAGE-TERMS.md: commercial-use terms

## Start Here

1. Double-click item-explorer.html.
2. Search or filter the library.
3. Select Random to generate a result from the current filters.
4. Export filtered CSV or JSON when you have the subset you need.

The premium pack expands the library to 500 records and adds biome, tone, richer descriptions, drawbacks, and more detailed source-table data.
