# Original Fantasy Item Starter Pack

This free starter pack contains 100 original fantasy item records for prototypes, tabletop prep, game jams, loot tables, shops, and placeholder inventories.

## Included Files

- `items.json`
- `items.csv`
- `schema.json`
- `examples.md`

## Data Fields

- ID, name, category, rarity, and tier
- Tags, description, and effect
- Value, weight, and source table

## Format Notes

- JSON is the canonical structured representation.
- CSV uses UTF-8 text, comma-separated columns, quoted values, and pipe-separated tags.

## Notes

- System-neutral.
- No art or icons included.
- Values and weights are placeholders for game balancing.
- Not affiliated with any game system, publisher, franchise, or brand.
- This is a review build and is not approved for public distribution.
