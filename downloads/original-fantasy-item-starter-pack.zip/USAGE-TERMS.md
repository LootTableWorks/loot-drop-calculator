# Loot Table Works Usage Terms

Version: 2026-07-10

These terms apply to the item data files distributed by Loot Table Works in the Original Fantasy Item Data Pack and its free starter pack.

## Permission

After purchase or authorized download, you may use and modify the item data in personal or commercial games, prototypes, tabletop materials, game jams, internal tools, and other creative projects.

## Redistribution

You may include original or adapted item data as part of a larger creative project. You may not resell, repackage, sublicense, or redistribute the source CSV or JSON files, or substantially equivalent extracted data, as a standalone or competing asset pack.

## Attribution

Attribution to Loot Table Works is appreciated but not required.

## Ownership

Loot Table Works retains its rights in the source pack. These terms grant permission to use the data; they do not transfer ownership of the source pack.

## Warranty

The pack is provided as-is, without warranties or guarantees. You are responsible for reviewing and adapting values, weights, rarity, effects, balance, and other content for your project.

## No Affiliation

This pack is not affiliated with, endorsed by, or sponsored by any game system, publisher, franchise, or brand.
