using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[Serializable]
public class FantasyItem
{
    public string id;
    public string name;
    public string category;
    public string rarity;
    public int tier;
    public string biome;
    public string tone;
    public string[] tags;
    public string description;
    public string short_description;
    public string table_description;
    public string effect;
    public string drawback;
    public int value;
    public float weight;
    public string source_table;
}

[Serializable]
internal class FantasyItemArray
{
    public FantasyItem[] items;
}

public class UnityItemDatabase : MonoBehaviour
{
    [SerializeField] private string resourcesFileName = "items";
    public IReadOnlyList<FantasyItem> Items => items;

    private readonly List<FantasyItem> items = new();

    private void Awake()
    {
        LoadFromResources();
    }

    public void LoadFromResources()
    {
        TextAsset jsonFile = Resources.Load<TextAsset>(resourcesFileName);
        if (jsonFile == null)
        {
            Debug.LogError($"Item database not found at Resources/{resourcesFileName}.json");
            return;
        }

        string wrappedJson = "{\"items\":" + jsonFile.text + "}";
        FantasyItemArray parsed = JsonUtility.FromJson<FantasyItemArray>(wrappedJson);
        items.Clear();
        if (parsed?.items != null)
        {
            items.AddRange(parsed.items);
        }
    }

    public FantasyItem FindById(string id)
    {
        return items.FirstOrDefault(item => item.id == id);
    }

    public List<FantasyItem> FindByCategory(string category)
    {
        return items.Where(item => item.category == category).ToList();
    }

    public FantasyItem RandomItem()
    {
        return items.Count == 0 ? null : items[UnityEngine.Random.Range(0, items.Count)];
    }
}
