# Integration Quickstart

The pack is system-neutral. Start with item-explorer.html if you want to browse or export a smaller subset without writing code.

## Unity

Use integrations/UnityItemDatabase.cs as a starting point.

1. Place the JSON file in Assets/Resources/.
2. Rename it to items.json if needed.
3. Add UnityItemDatabase to a GameObject.
4. Call FindById, FindByCategory, or RandomItem.

Unity's built-in JSON utility does not accept a top-level array, so the example wraps the array before parsing it.

## Godot 4

Use integrations/GodotItemDatabase.gd.

1. Place the JSON file in the project, such as res://data/items-premium.json.
2. Attach the script or autoload it.
3. Call load_items, then use find_by_id, filter_by_category, or random_item.

## Browser Or Node.js

Use integrations/JavaScriptItemLoader.js.

- In a browser project, fetch the JSON through your local development server.
- In Node.js, read and parse the file with the built-in fs module.

## Important

- Values, weights, effects, and drawbacks are placeholders that should be balanced for your game.
- Preserve item IDs if other project data references them.
- Validate edited JSON against schema.json.
